﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Sgaragli
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Calciatore> calciatori;
        public MainWindow()
        {
            InitializeComponent();
        }
        bool flag = false;

        private void Aggiorna_Click(object sender, RoutedEventArgs e)
        {
            lstCalciatori.Items.Clear();
            flag = true;
            Task.Factory.StartNew(()=>CaricaDati());

        }

        private void CaricaDati()
        {
            calciatori = new List<Calciatore>();
            string path = @"presenze.xml";
            XDocument xmlDoc = XDocument.Load(path);
            XElement xmlcalciatori = xmlDoc.Element("calciatori");
            var xmlcalciatore = xmlcalciatori.Elements("calciatore");



            foreach (var item in xmlcalciatore)
            {
                XElement xmlfirstname = item.Element("nome");
                XElement xmllastname = item.Element("cognome");
                XElement xmlpresenze = item.Element("presenze");
                XElement xmlnascita = item.Element("data");
                Calciatore a = new Calciatore();
                a.Nome = xmlfirstname.Value;
                a.Cognome = xmllastname.Value;
                a.Presenze = Convert.ToInt32(xmlpresenze.Value);
                a.DataNascita = Convert.ToDateTime(xmlnascita.Value);
                calciatori.Add(a);
                Dispatcher.Invoke(() => lstCalciatori.ItemsSource = calciatori);
                Thread.Sleep(500);
                if (!flag)
                    break;

            }
            
        }

        private void Btn_stop_Click(object sender, RoutedEventArgs e)
        {
            flag=false;
        }
    }
}
